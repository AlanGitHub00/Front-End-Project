import { Point } from "arcgis-rest-api";

let point: Point;

point = {
    x: -122.6764,
    y: 45.5165,
    spatialReference: {
      wkid: 4326
    }
};
