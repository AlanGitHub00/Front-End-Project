import Abs = require('abs');

const x: string = Abs('/foo');
