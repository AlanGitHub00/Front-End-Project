
import absolute from 'absolute';

const x: boolean = absolute('/home/foo');
