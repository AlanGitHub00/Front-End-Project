import arrayUniq = require("array-uniq");

arrayUniq([1, 1, 2, 3, 3]);

arrayUniq(["foo", "foo", "bar", "foo"]);
