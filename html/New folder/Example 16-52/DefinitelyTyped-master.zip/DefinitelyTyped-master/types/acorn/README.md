This file exists for reminding contributors that this definition is **WIP**.

### Note

There are a **large** number of methods of class `Parser` and `LooseParser` haven't been declared.

However, these methods may not be useful for common users. So, I hang the job util it worth continuing.

Of course, volunteers are welcomed to spend time extracting these things.
