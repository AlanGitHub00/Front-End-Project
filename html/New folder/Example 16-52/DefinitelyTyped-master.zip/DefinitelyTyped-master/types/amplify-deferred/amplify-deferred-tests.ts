amplify.request({
    resourceId: "statusExample1"
}).done((data, status) => {
}).fail((data, status) => {
}).always((data, status) => { });
