import * as anybar from 'anybar'

anybar('red', { port: 123 })

anybar('green')
